import java.util.ArrayList;

public class Product {

    private String name;
    private String price;

    public Product(String name, String price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public static ArrayList<Double> getInvoice(ArrayList<Product> products) {
        ArrayList<Double> prices = new ArrayList<>();
        for (Product product: products) {
            prices.add(Double.parseDouble(product.getPrice()));
        }
        return prices;
    }

    public static ArrayList<String> getProductsNames(ArrayList<Product> products) {
        ArrayList<String> productsNames = new ArrayList<>();
        for (Product product: products) {
            productsNames.add(product.getName());
        }
        return productsNames;
    }
}
