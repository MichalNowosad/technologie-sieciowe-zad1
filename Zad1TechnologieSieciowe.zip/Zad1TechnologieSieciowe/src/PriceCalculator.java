import java.util.ArrayList;

public class PriceCalculator {

    public static double getSum(ArrayList<Product> products) {
        double sum = 0;
        for (Product product: products) {
            sum += Double.parseDouble(product.getPrice());
        }
        return sum;
    }

    public static double getAvg(ArrayList<Product> products) {
        double avg = PriceCalculator.getSum(products)/products.size();
        return avg;
    }
}
