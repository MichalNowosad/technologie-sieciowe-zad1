import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

@WebServlet("/shoplist")
public class Controler extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String productName1 = request.getParameter("product1");
        String productName2 = request.getParameter("product2");
        String productName3 = request.getParameter("product3");
        String productName4 = request.getParameter("product4");

        String price1 = request.getParameter("price1");
        String price2 = request.getParameter("price2");
        String price3 = request.getParameter("price3");
        String price4 = request.getParameter("price4");

        ArrayList<Product> products = new ArrayList<>();

        products.add(new Product(productName1, price1));
        products.add(new Product(productName2, price2));
        products.add(new Product(productName3, price3));
        products.add(new Product(productName4, price4));

        Iterator itr = products.iterator();
        while (itr.hasNext())
        {
            Product product = (Product) itr.next();
            if (product.getName().isEmpty() || product.getPrice().isEmpty())
                itr.remove();
        }

        double avg =PriceCalculator.getAvg(products);
        double sum =PriceCalculator.getSum(products);


        if (price1.isEmpty() && price2.isEmpty() && price3.isEmpty() && price4.isEmpty()) {
            request.getRequestDispatcher("noitems.jsp").forward(request, response);
        } else {
            request.setAttribute("prices", Product.getInvoice(products));
            request.setAttribute("productsNames", Product.getProductsNames(products));
            request.setAttribute("sum", sum);
            request.setAttribute("average", avg);
            request.getRequestDispatcher("basket.jsp").forward(request, response);

        }
    }

}
